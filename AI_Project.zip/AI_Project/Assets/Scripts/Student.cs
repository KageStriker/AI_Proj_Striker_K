﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using States;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class Student : MonoBehaviour
{
    protected float energy = 100;
    protected float stamina = 100;
    protected float hunger = 0;
    protected float reputation = 0;
    protected float money = 30;

    public bool waitComplete;
    
    public NavMeshAgent nmAgent;
    
    public StudentFSM<Student> stateMachine { get; set; }


    private void Start()
    {
        nmAgent = GetComponent<NavMeshAgent>();
        stateMachine = new StudentFSM<Student>(this);

        stateMachine.ChangeState(CalculateTaskState.Instance);
    }

    private void Update()
    {
        stateMachine.Update();
    }

    public float getEnergy()
    {
        return energy;
    }

    public float getStamina()
    {
        return stamina;
    }

    public float getHunger()
    {
        return hunger;
    }

    public float getRep()
    {
        return reputation;
    }

    public int getMoney()
    {
        return Mathf.RoundToInt(money);
    }

    public void setMoney(int _money)
    {
        money = _money;
    }

    public IEnumerator WaitForDuration(float duration)
    {
        yield return new WaitForSeconds(duration);
        waitComplete = true;
        yield return new WaitForEndOfFrame();
        waitComplete = false;
    }
}
