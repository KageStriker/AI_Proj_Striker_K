﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using States;
using System;

public class CalculateTaskState : State<Student>
{
    private static CalculateTaskState _instance;

    private CalculateTaskState()
    {
        if (_instance != null)
        {
            return;
        }

        _instance = this;
    }

    public static CalculateTaskState Instance
    {
        get
        {
            if (_instance == null)
            {
                new CalculateTaskState();
            }

            return _instance;
        }
    }

    public override void EnterState(Student _owner)
    {
        Debug.Log("Entering Calculate Task State");
        if (_owner.getMoney() > 50)
        {
            _owner.stateMachine.ChangeState(NewClassState.Instance);
            _owner.setMoney(_owner.getMoney() - 35);
        }
        else if (_owner.getMoney() < 5 && _owner.getEnergy() < 10 && _owner.getStamina() < 10)
        {
            _owner.stateMachine.ChangeState(WorkState.Instance);
        }
        else if (_owner.getEnergy() >= 50 && _owner.getStamina() >= 50)
        {
            _owner.stateMachine.ChangeState(StudyState.Instance);
        }
        else if (_owner.getEnergy() < 10 || _owner.getStamina() < 10)
        {
            if (_owner.getEnergy() < 10 && _owner.getStamina() > 10)
            {
                _owner.stateMachine.ChangeState(EatState.Instance);
            }
            else if (_owner.getEnergy() > 10 && _owner.getStamina() < 10)
            {
                _owner.stateMachine.ChangeState(SleepState.Instance);
            }
            else if (_owner.getEnergy() < 10 && _owner.getStamina() < 10)
            {
                _owner.stateMachine.ChangeState(DropOutState.Instance);
            }
            else
                _owner.stateMachine.ChangeState(StudyState.Instance);
        }
        else
            _owner.stateMachine.ChangeState(StudyState.Instance);
    }

    public override void ExitState(Student _owner)
    {
        Debug.Log("Exiting Calculate Task State");
    }

    public override void UpdateState(Student _owner)
    {

    }
}
