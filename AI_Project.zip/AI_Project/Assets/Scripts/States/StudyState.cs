﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using States;
using System;

public class StudyState : State<Student>
{
    private static StudyState _instance;

    private GameObject[] studyGO;
    public Collider[] studyAreas;
    private Collider[] studentsInArea;
    private Vector3 currentDestination;
    private Vector3 leftSpot = new Vector3(4,0,0);
    private Vector3 rightSpot = new Vector3(-4, 0, 0);
    private bool allowChange = false;
    static int pos;

    private StudyState()
    {
        if(_instance != null)
        {
            return;
        }

        _instance = this;

        studyGO = GameObject.FindGameObjectsWithTag("Study");
        studyAreas = new Collider[3];
        for(int i = 0; i < 3; i++)
        {
            studyAreas[i] = studyGO[i].GetComponent<Collider>();
        }
    }

    public static StudyState Instance
    {
        get
        {
            if(_instance == null)
            {
                new StudyState();
            }

            return _instance;
        }
    }

    public override void EnterState(Student _owner)
    {
        Debug.Log("Entering Study State");

        for (int i = 0; i < 3; i++)
        {
            if (pos > 2)
            {
                pos = 0;
            }
            else
            {
                switch (pos)
                {
                    case 0:
                        currentDestination = studyAreas[i].transform.position + leftSpot;
                        _owner.nmAgent.SetDestination(currentDestination);
                        break;
                    case 1:
                        currentDestination = studyAreas[i].transform.position;
                        _owner.nmAgent.SetDestination(currentDestination);
                        break;
                    case 2:
                        currentDestination = studyAreas[i].transform.position + rightSpot;
                        _owner.nmAgent.SetDestination(currentDestination);
                        break;
                }
            }
            pos++;
            break;
        }
        Debug.Log(currentDestination);
    }

    public override void ExitState(Student _owner)
    {

    }

    public override void UpdateState(Student _owner)
    {
        if(_owner.nmAgent.destination == currentDestination)
        {
            _owner.nmAgent.isStopped = true;
            _owner.stateMachine.ChangeState(IdleState.Instance);
        }
    }
}
